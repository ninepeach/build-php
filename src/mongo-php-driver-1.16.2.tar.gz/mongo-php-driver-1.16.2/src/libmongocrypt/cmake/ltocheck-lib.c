
extern int
answer (int a, int b)
{
   return a + b;
}